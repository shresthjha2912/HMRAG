"""Qwen-VL based image-to-text for MMKG ingestion.

Uses the Qwen2.5-VL model (or Qwen-VL-Chat) via transformers to generate
rich textual descriptions from images, grounded in the question context.
"""

import base64
import os
from pathlib import Path
from typing import Optional

import torch
from PIL import Image


# ---------------------------------------------------------------------------
# Lazy-loaded globals so the model is only loaded once per process
# ---------------------------------------------------------------------------
_model = None
_processor = None
_device = None


def _load_qwen_vl(model_name: str = "Qwen/Qwen2.5-VL-3B-Instruct"):
    """Load Qwen-VL model and processor (cached after first call)."""
    global _model, _processor, _device

    if _model is not None:
        return _model, _processor, _device

    from transformers import Qwen2_5_VLForConditionalGeneration, AutoProcessor

    _device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.float16 if _device == "cuda" else torch.float32

    print(f"[vlm_qwen] Loading {model_name} on {_device} (dtype={dtype}) ...")
    _processor = AutoProcessor.from_pretrained(model_name, trust_remote_code=True)
    _model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
        model_name,
        torch_dtype=dtype,
        device_map="auto" if _device == "cuda" else None,
        trust_remote_code=True,
    )
    if _device == "cpu":
        _model = _model.to(_device)
    _model.eval()
    print(f"[vlm_qwen] Model loaded.")
    return _model, _processor, _device


def describe_image_qwen(
    image_path: str,
    question: str = "",
    hint: str = "",
    caption: str = "",
    model_name: str = "Qwen/Qwen2.5-VL-3B-Instruct",
    max_new_tokens: int = 512,
) -> str:
    """Generate a textual description of an image using Qwen-VL.

    The description is grounded in the question/hint/caption context so that
    the extracted text is relevant to the downstream QA task.

    Returns:
        A string with the image description / extracted evidence.
    """
    if not image_path or not os.path.exists(image_path):
        return ""

    model, processor, device = _load_qwen_vl(model_name)

    # Build the prompt
    context_parts = []
    if question:
        context_parts.append(f"Question: {question}")
    if hint:
        context_parts.append(f"Hint: {hint}")
    if caption:
        context_parts.append(f"Caption: {caption}")
    context_str = "\n".join(context_parts)

    user_prompt = (
        "You are an expert image analyst helping answer a science question.\n"
        f"{context_str}\n\n"
        "Look at the image carefully. Describe ALL relevant visual information "
        "including: objects, labels, text, diagrams, charts, maps, arrows, colors, "
        "spatial relationships, and any data shown. Be thorough and factual. "
        "Focus on details that help answer the question."
    )

    # Build messages in Qwen2.5-VL chat format
    image = Image.open(image_path).convert("RGB")

    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image},
                {"type": "text", "text": user_prompt},
            ],
        }
    ]

    # Process with the Qwen2.5-VL processor
    text_prompt = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = processor(
        text=[text_prompt],
        images=[image],
        padding=True,
        return_tensors="pt",
    )
    inputs = {k: v.to(model.device) if hasattr(v, "to") else v for k, v in inputs.items()}

    with torch.no_grad():
        generated_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
        )

    # Decode only the newly generated tokens
    input_len = inputs["input_ids"].shape[1]
    output_ids = generated_ids[:, input_len:]
    result = processor.batch_decode(output_ids, skip_special_tokens=True)[0].strip()

    return result