"""
Summary agent for HM‑RAG.

This module implements the summarisation component described in the
HM‑RAG paper.  It aggregates the outputs of the retrieval agents,
combines them with the original question and context (via the
``prompts`` module) and produces a final answer prediction.  The
implementation here is taken verbatim from the original code shared by
the user, with only minimal additions: a module‑level docstring and
imports of the ``build_prompt`` function from ``prompts``.

The summarisation pipeline works as follows:

1. Determine whether the majority of retrieval results agree on a
   single answer.  If so, map that answer (e.g. ``'B'``) to its
   index in the list of answer choices.
2. If there is disagreement, construct a prompt using the few‑shot
   examples and the current question.  Optionally include an image
   path if the problem has an associated image.
3. Use either a text‑only LLM (Ollama) or a vision‑language model
   (Qwen2.5‑VL) to reason over the retrieved evidence and produce a
   chain‑of‑thought.  Extract the final answer token from the
   generated output.

The class is not meant to be executed in isolation; it is invoked by
``multi_retrieval_agent.MRetrievalAgent``.  See that module for
integration details.
"""

from collections import Counter
import random
import os
import re
from typing import List, Tuple

from langchain_community.llms.ollama import Ollama
from transformers import Qwen2_5_VLForConditionalGeneration, AutoProcessor
from qwen_vl_utils import process_vision_info

from prompts import build_prompt


class SummaryAgent:
    def __init__(self, config) -> None:
        self.config = config
        # LLM for text reasoning
        self.text_llm = Ollama(base_url="http://localhost:11434", model="qwen2.5:14b")
        # Vision‑language model and processor
        self.processor = AutoProcessor.from_pretrained(
            "Qwen/Qwen2.5-VL-7B-Instruct", use_fast=True
        )
        self.model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
            "Qwen/Qwen2.5-VL-7B-Instruct", torch_dtype="auto", device_map="auto"
        )

    def summarize(self, problems: dict, shot_qids: List[str], qid: str, cur_ans: List[str]) -> Tuple[int, List[str]]:
        problem = problems[qid]
        question = problem["question"]
        choices = problem["choices"]
        answer = problem["answer"]
        image = problem.get("image")
        caption = problem.get("caption")
        split = problem.get("split")

        most_ans = self.get_most_common_answer(cur_ans)
        if len(most_ans) == 1:
            prediction = self.get_result(most_ans[0])  # 'A'..'E'
            pred_idx = self.get_pred_idx(prediction, choices, self.config.options)
        else:
            # Determine image path if there is an image associated
            if image == "image.png":
                image_path = os.path.join(self.config.image_root, split, qid, image)
            else:
                image_path = ""
            output_text = cur_ans[0]
            output_graph = cur_ans[1]
            output_web = cur_ans[2]
            output = self.refine(
                output_text, output_graph, output_web,
                problems, shot_qids, qid, self.config, image_path
            )
            if output is None:
                output = "FAILD"
            print(f"output: {output}")
            ans_fusion = self.get_result(output)
            pred_idx = self.get_pred_idx(ans_fusion, choices, self.config.options)
        return pred_idx, cur_ans

    @staticmethod
    def get_most_common_answer(res: List[str]) -> List[str]:
        """Return the list of most frequent answers from the retrieval outputs."""
        counter = Counter(res)
        max_count = max(counter.values()) if counter else 0
        most_common_values = [item for item, count in counter.items() if count == max_count]
        return most_common_values

    def refine(
        self,
        output_text: str,
        output_graph: str,
        output_web: str,
        problems: dict,
        shot_qids: List[str],
        qid: str,
        args,
        image_path: str,
    ) -> str:
        """Use an LLM (text or vision) to reason over the retrieved outputs."""
        prompt = build_prompt(problems, shot_qids, qid, args)
        # Append instruction for answer extraction
        prompt = f"{prompt} The answer is A, B, C, D, E or FAILED. \n BECAUSE: "
        if not image_path:
            output = self.text_llm.invoke(prompt)
        else:
            output = self.qwen_reasoning(prompt, image_path)
            print(f"**** output: {output}")
            # Qwen returns a list of strings; we only need the first
            if isinstance(output, list) and output:
                output = output[0]
            # Summarise the reasoning with the text LLM
            output = self.text_llm.invoke(
                f"{output} Summary the above information with format 'Answer: The answer is A, B, C, D, E or FAILED.    \n BECAUSE: '"
            )
        return output

    @staticmethod
    def get_result(output: str) -> str:
        """Extract the answer letter from the LLM output."""
        pattern = re.compile(r"The answer is ([A-E])")
        res = pattern.findall(output)
        if len(res) == 1:
            answer = res[0]
        else:
            answer = "FAILED"
        return answer

    @staticmethod
    def get_pred_idx(prediction: str, choices: List[str], options: List[str]) -> int:
        """Map an answer letter to its index in the list of choices."""
        if prediction in options[: len(choices)]:
            return options.index(prediction)
        else:
            return random.choice(range(len(choices)))

    def qwen_reasoning(self, prompt: str, image_path: str):
        """Invoke the vision‑language model for reasoning with an image."""
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "image": image_path,
                    },
                    {"type": "text", "text": prompt},
                ],
            }
        ]
        # Prepare inputs for the VL model
        text = self.processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        image_inputs, video_inputs = process_vision_info(messages)
        inputs = self.processor(
            text=[text],
            images=image_inputs,
            videos=video_inputs,
            padding=True,
            return_tensors="pt",
        )
        inputs = inputs.to(self.model.device)
        # Generate output
        generated_ids = self.model.generate(**inputs, max_new_tokens=2048)
        generated_ids_trimmed = [
            out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
        ]
        output_text = self.processor.batch_decode(
            generated_ids_trimmed,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False,
        )
        return output_text