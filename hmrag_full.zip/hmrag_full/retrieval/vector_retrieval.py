"""
VectorRetrieval module for HM‑RAG (duplicate).

This file is a copy of the top‑level ``retrieval/vector_retrieval.py``
to make the ``hmrag_full`` directory self‑contained.  For full
documentation and usage examples, see the original module.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Sequence

try:
    from qdrant_client import QdrantClient
except ImportError:
    QdrantClient = None  # type: ignore

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None  # type: ignore


LOGGER = logging.getLogger(__name__)


def default_embed_fn(texts: Sequence[str], model_name: str, api_key: str) -> List[List[float]]:
    """Use OpenAI to compute embeddings for a sequence of texts."""
    if OpenAI is None:
        raise RuntimeError("OpenAI package is not installed. Install openai>=1.0.0.")
    if not api_key:
        raise RuntimeError("OpenAI API key is required to compute embeddings.")
    client = OpenAI(api_key=api_key)
    try:
        resp = client.embeddings.create(model=model_name, input=list(texts), encoding_format="float")
    except Exception as exc:
        raise RuntimeError(f"Error calling OpenAI embeddings API: {exc}") from exc
    return [d.embedding for d in resp.data]


@dataclass
class VectorRetrievalConfig:
    """Configuration for VectorRetrieval."""

    qdrant_host: str = "localhost"
    qdrant_port: int = 6333
    qdrant_api_key: Optional[str] = None
    qdrant_collection: str = "hmrag_collection"
    vector_top_k: int = 5
    score_threshold: Optional[float] = None
    openai_api_key: Optional[str] = None
    embedding_model_name: str = "text-embedding-3-small"
    embed_fn: Optional[Callable[[Sequence[str]], List[List[float]]]] = None
    # If you're using Qdrant Cloud, set qdrant_https=True and host to your domain.
    qdrant_https: bool = False
    # Optional: pass a full URL like "https://xxxx.qdrant.tech".
    qdrant_url: Optional[str] = None


class VectorRetrieval:
    """Vector retrieval agent using Qdrant."""

    def __init__(self, config: Any) -> None:
        self.host = getattr(config, "qdrant_host", None) or "localhost"
        self.port = getattr(config, "qdrant_port", None) or 6333
        self.api_key = getattr(config, "qdrant_api_key", None)
        self.https = bool(getattr(config, "qdrant_https", False))
        self.url_override = getattr(config, "qdrant_url", None)
        self.collection = getattr(config, "qdrant_collection", None) or getattr(config, "collection", "hmrag_collection")
        self.top_k = getattr(config, "vector_top_k", None) or getattr(config, "top_k", 5)
        self.score_threshold = getattr(config, "score_threshold", None)
        self.embed_fn_override: Optional[Callable[[Sequence[str]], List[List[float]]]] = getattr(config, "embed_fn", None)
        self.embedding_model_name = getattr(config, "embedding_model_name", "text-embedding-3-small")
        self.openai_api_key = getattr(config, "openai_api_key", None)

        if QdrantClient is None:
            raise ImportError(
                "qdrant_client package is required for VectorRetrieval. Install it via 'pip install qdrant-client'."
            )
        try:
            if self.url_override:
                url = str(self.url_override)
            else:
                # If host already contains scheme, respect it.
                if str(self.host).startswith("http://") or str(self.host).startswith("https://"):
                    url = str(self.host)
                else:
                    scheme = "https" if self.https else "http"
                    url = f"{scheme}://{self.host}:{self.port}"
            self.client = QdrantClient(url=url, api_key=self.api_key)
        except Exception as exc:
            raise RuntimeError(f"Failed to create QdrantClient: {exc}") from exc

    def _embed(self, texts: Sequence[str]) -> List[List[float]]:
        """Compute embeddings for a list of strings."""
        if self.embed_fn_override is not None:
            return self.embed_fn_override(texts)
        return default_embed_fn(texts, self.embedding_model_name, self.openai_api_key)  # type: ignore[arg-type]

    def _search(self, query_vec: List[float]) -> List[Dict[str, Any]]:
        """Perform a similarity search against Qdrant."""
        try:
            # Try new API first (qdrant-client >= 1.7.0)
            if hasattr(self.client, 'query_points'):
                from qdrant_client.models import QueryRequest, VectorInput
                hits = self.client.query_points(
                    collection_name=self.collection,
                    query=query_vec,
                    limit=self.top_k,
                    with_payload=True,
                    score_threshold=self.score_threshold,
                ).points
            elif hasattr(self.client, 'search_points'):
                hits = self.client.search_points(
                    collection_name=self.collection,
                    query=query_vec,
                    limit=self.top_k,
                    with_payload=True,
                    score_threshold=self.score_threshold,
                ).points
            else:
                # Fallback to old API
                hits = self.client.search(
                    collection_name=self.collection,
                    query_vector=query_vec,
                    limit=self.top_k,
                    with_vectors=False,
                    with_payload=True,
                    score_threshold=self.score_threshold,
                )
        except Exception as exc:
            raise RuntimeError(f"Qdrant search failed: {exc}") from exc
        return [
            {
                "id": hit.id,
                "score": hit.score,
                "payload": hit.payload,
            }
            for hit in hits
        ]

    def find_top_k(self, queries: Any) -> str:
        """Entry point used by ``multi_retrieval_agent``."""
        if isinstance(queries, (list, tuple)):
            query_text = "; ".join(str(q) for q in queries)
        else:
            query_text = str(queries)

        print(f"  🔍 VectorRetrieval.find_top_k()")
        print(f"     Collection: {self.collection}")
        print(f"     Top-K: {self.top_k}")
        print(f"     Query text: {query_text[:120]}{'...' if len(query_text)>120 else ''}")

        # Embed the query
        print(f"     Embedding query using {self.embedding_model_name} ...")
        query_vecs = self._embed([query_text])
        if not query_vecs:
            print(f"     ⚠ Embedding failed!")
            return f"No embedding could be generated for query: {query_text}"
        query_vec = query_vecs[0]
        print(f"     ✓ Got embedding vector (dim={len(query_vec)})")

        # Search Qdrant
        print(f"     Searching Qdrant ...")
        hits = self._search(query_vec)
        print(f"     ✓ Got {len(hits)} hits")
        if not hits:
            print(f"     ⚠ No results found!")
            return f"No relevant results were found in the vector database for query: {query_text}"

        # Format results
        lines: List[str] = []
        for idx, hit in enumerate(hits, start=1):
            score = hit.get("score")
            payload = hit.get("payload", {})
            text = payload.get("text", "")
            doc_id = payload.get("doc_id", payload.get("qid", ""))
            chunk_index = payload.get("chunk_index", "")
            vision_text = payload.get("vision_text", "")
            print(f"     Hit {idx}: score={score:.4f} doc={doc_id} chunk={chunk_index}")
            print(f"          Text: {text[:100]}{'...' if len(text)>100 else ''}")
            if vision_text:
                print(f"          VLM:  {vision_text[:80]}{'...' if len(vision_text)>80 else ''}")
            lines.append(f"{idx}. [doc {doc_id} chunk {chunk_index}] score={score:.3f}: {text}")
        return "\n".join(lines)