"""
GraphRetrieval module for HM‑RAG (duplicate).

This file is a copy of the top‑level ``retrieval/graph_retrieval.py``
to make the ``hmrag_full`` directory self‑contained.  For full
documentation and usage examples, see the original module.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

try:
    from neo4j import GraphDatabase, Record
except ImportError:
    GraphDatabase = None  # type: ignore
    Record = Any  # type: ignore


LOGGER = logging.getLogger(__name__)


@dataclass
class GraphRetrievalConfig:
    """Configuration for GraphRetrieval."""

    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = "password"
    graph_top_k: int = 5
    graph_query_fn: Optional[Callable[[str], Tuple[str, Dict[str, Any]]]] = None


class GraphRetrieval:
    """Graph retrieval agent using Neo4j."""

    def __init__(self, config: Any) -> None:
        if GraphDatabase is None:
            raise ImportError(
                "neo4j package is required for GraphRetrieval. Install it via 'pip install neo4j'."
            )
        self.uri = getattr(config, "neo4j_uri", "bolt://localhost:7687")
        self.user = getattr(config, "neo4j_user", "neo4j")
        self.password = getattr(config, "neo4j_password", "password")
        self.top_k = getattr(config, "graph_top_k", 5)
        self.custom_query_fn: Optional[Callable[[str], Tuple[str, Dict[str, Any]]]] = getattr(
            config, "graph_query_fn", None
        )
        try:
            self.driver = GraphDatabase.driver(self.uri, auth=(self.user, self.password))
        except Exception as exc:
            raise RuntimeError(f"Failed to connect to Neo4j at {self.uri}: {exc}") from exc

    def _default_query(self, query: str) -> Tuple[str, Dict[str, Any]]:
        cypher = (
            "MATCH (n)\n"
            "WHERE toLower(n.name) CONTAINS toLower($q) OR toLower(n.text) CONTAINS toLower($q)\n"
            "OPTIONAL MATCH (n)-[r]->(m)\n"
            "RETURN n, r, m\n"
            "LIMIT $limit"
        )
        params = {"q": query, "limit": self.top_k}
        return cypher, params

    def _run_query(self, cypher: str, params: Dict[str, Any]) -> List[Record]:
        with self.driver.session() as session:
            try:
                result = session.run(cypher, params)
            except Exception as exc:
                raise RuntimeError(f"Failed to execute graph query: {exc}") from exc
            return list(result)

    def _format_results(self, records: List[Record], query: str) -> str:
        if not records:
            return f"No relevant entities were found in the knowledge graph for query: {query}"
        lines: List[str] = []
        count = 0
        for record in records:
            n = record.get("n")
            r = record.get("r")
            m = record.get("m")
            n_label = ":".join(n.labels) if hasattr(n, "labels") else ""
            n_name = n.get("name", "<unnamed>") if hasattr(n, "get") else str(n)
            line = f"Entity: {n_name} ({n_label})"
            if r is not None and m is not None:
                r_type = type(r).__name__ if hasattr(r, "__class__") else "REL"
                m_label = ":".join(m.labels) if hasattr(m, "labels") else ""
                m_name = m.get("name", "<unnamed>") if hasattr(m, "get") else str(m)
                line += f" --[{r_type}]-> {m_name} ({m_label})"
            lines.append(line)
            count += 1
            if count >= self.top_k:
                break
        return "\n".join(lines)

    def find_top_k(self, queries: Any) -> str:
        if isinstance(queries, (list, tuple)):
            query_text = "; ".join(str(q) for q in queries)
        else:
            query_text = str(queries)

        print(f"  🕸️  GraphRetrieval.find_top_k()")
        print(f"     Neo4j URI: {self.uri}")
        print(f"     Top-K: {self.top_k}")
        print(f"     Query text: {query_text[:120]}{'...' if len(query_text)>120 else ''}")

        if self.custom_query_fn is not None:
            print(f"     Using custom query function")
            cypher, params = self.custom_query_fn(query_text)
            params = params or {}
            params.setdefault("limit", self.top_k)
        else:
            print(f"     Using default Cypher query")
            cypher, params = self._default_query(query_text)

        print(f"     Cypher: {cypher.strip()}")
        safe_params = {k: v for k, v in params.items()}
        print(f"     Params: q='{str(safe_params.get('q',''))[:60]}...', limit={safe_params.get('limit')}")

        print(f"     Executing query ...")
        records = self._run_query(cypher, params)
        print(f"     ✓ Got {len(records)} records")

        for i, record in enumerate(records[:self.top_k], 1):
            n = record.get("n")
            r = record.get("r")
            m = record.get("m")
            n_name = n.get("name", "<unnamed>") if hasattr(n, "get") else str(n)
            line = f"     Record {i}: {n_name}"
            if r is not None and m is not None:
                r_type = type(r).__name__ if hasattr(r, "__class__") else "REL"
                m_name = m.get("name", "<unnamed>") if hasattr(m, "get") else str(m)
                line += f" --[{r_type}]--> {m_name}"
            print(line)

        return self._format_results(records, query_text)