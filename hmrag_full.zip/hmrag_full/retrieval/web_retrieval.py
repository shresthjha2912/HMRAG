"""
WebRetrieval module for HM‑RAG (duplicate).

This file is a copy of the top‑level ``retrieval/web_retrieval.py``
to make the ``hmrag_full`` directory self‑contained.  For full
documentation and usage examples, see the original module.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Sequence

try:
    import requests
except ImportError:
    requests = None  # type: ignore


LOGGER = logging.getLogger(__name__)


class WebRetrieval:
    """Web retrieval agent using Serper."""

    def __init__(self, config: Any) -> None:
        self.api_key: Optional[str] = getattr(config, "serper_api_key", None)
        self.top_k: int = getattr(config, "serper_top_k", 5)

    def _search_serper(self, query: str) -> List[Dict[str, str]]:
        if requests is None:
            raise ImportError(
                "The requests library is required for web search. Install it via 'pip install requests'."
            )
        if not self.api_key:
            raise RuntimeError(
                "Serper API key is not configured. Please set 'serper_api_key' in your configuration."
            )
        headers = {
            "X-API-KEY": self.api_key,
            "Content-Type": "application/json",
        }
        payload = {
            "q": query,
            "num": self.top_k,
            "autocorrect": True,
        }
        try:
            response = requests.post(
                "https://google.serper.dev/search", headers=headers, data=json.dumps(payload), timeout=30
            )
        except Exception as exc:
            raise RuntimeError(f"Failed to call Serper API: {exc}") from exc
        if response.status_code != 200:
            raise RuntimeError(f"Serper API returned status {response.status_code}: {response.text}")
        data = response.json()
        results: List[Dict[str, str]] = []
        for item in data.get("organic", [])[: self.top_k]:
            title = item.get("title", "")
            link = item.get("link", "")
            snippet = item.get("snippet", "")
            results.append({"title": title, "link": link, "snippet": snippet})
        return results

    def _format_results(self, results: List[Dict[str, str]], query: str) -> str:
        if not results:
            return f"No relevant results were found on the web for query: {query}"
        lines: List[str] = []
        for idx, item in enumerate(results, start=1):
            title = item.get("title", "<no title>")
            link = item.get("link", "<no link>")
            snippet = item.get("snippet", "")
            lines.append(f"{idx}. {title}\n   {snippet}\n   {link}")
        return "\n".join(lines)

    def find_top_k(self, queries: Any) -> str:
        if isinstance(queries, (list, tuple)):
            query_text = "; ".join(str(q) for q in queries)
        else:
            query_text = str(queries)

        print(f"  🌐 WebRetrieval.find_top_k()")
        print(f"     Top-K: {self.top_k}")
        print(f"     API key configured: {'Yes' if self.api_key else 'NO'}")
        print(f"     Query text: {query_text[:120]}{'...' if len(query_text)>120 else ''}")

        try:
            print(f"     Calling Serper API ...")
            results = self._search_serper(query_text)
            print(f"     ✓ Got {len(results)} web results")
            for i, item in enumerate(results, 1):
                print(f"     Result {i}: {item.get('title', '(no title)')}")
                print(f"               {item.get('link', '')}")
                print(f"               {item.get('snippet', '')[:80]}...")
        except Exception as exc:
            print(f"     ⚠ Web search error: {exc}")
            return f"Web search error: {exc}"
        return self._format_results(results, query_text)