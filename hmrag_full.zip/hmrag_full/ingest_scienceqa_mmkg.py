"""MMKG-style ingestion for HM-RAG reproduction.

This script extends the *text-only* ingestion by:
  1) Running Qwen-VL (or a hosted VLM) to convert each image into refined text.
  2) Extracting entities/relations from fused evidence and writing them
     into Neo4j (lightweight MMKG) with vector indexes.
  3) Upserting chunk embeddings into Qdrant.

The existing agent/retrieval files are kept intact. This is an
additional ingestion option.
"""

import argparse
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import uuid  # Add this import

from neo4j import GraphDatabase
from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels
from tqdm import tqdm

from openai import OpenAI

try:
    from hmrag_full.vlm_mmkg import describe_image_openai, describe_image_hf_endpoint, extract_kg_openai
    from .vlm_qwen import describe_image_qwen
except Exception:
    from hmrag_full.vlm_mmkg import describe_image_openai, describe_image_hf_endpoint, extract_kg_openai
    from hmrag_full.vlm_qwen import describe_image_qwen


def chunk_text(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    if not text:
        return []
    text = text.replace("\r\n", "\n")
    chunks = []
    i = 0
    n = len(text)
    while i < n:
        j = min(n, i + chunk_size)
        chunks.append(text[i:j])
        if j == n:
            break
        i = max(0, j - chunk_overlap)
    return chunks


def embed_texts_openai(texts: List[str], model_name: str, api_key: str, batch_size: int = 64) -> List[List[float]]:
    client = OpenAI(api_key=api_key)
    out: List[List[float]] = []
    for i in range(0, len(texts), batch_size):
        resp = client.embeddings.create(model=model_name, input=texts[i : i + batch_size], encoding_format="float")
        out.extend([d.embedding for d in resp.data])
    return out


def ensure_qdrant_collection(client: QdrantClient, collection: str, vector_size: int) -> None:
    existing = {c.name for c in client.get_collections().collections}
    if collection in existing:
        return
    client.create_collection(
        collection_name=collection,
        vectors_config=qmodels.VectorParams(size=vector_size, distance=qmodels.Distance.COSINE),
    )


def _stable_chunk_id(qid: str, chunk_idx: int, text: str) -> str:
    """Generate a stable string ID for Neo4j."""
    h = hashlib.sha1((qid + "::" + str(chunk_idx) + "::" + text).encode("utf-8")).hexdigest()[:16]
    return f"{qid}_{chunk_idx}_{h}"


def _chunk_id_to_uuid(chunk_id: str) -> str:
    """Convert string chunk_id to UUID for Qdrant."""
    # Create deterministic UUID from string
    namespace = uuid.UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')  # Standard namespace
    return str(uuid.uuid5(namespace, chunk_id))


def ensure_neo4j_indexes(driver) -> None:
    """Create fulltext indexes AND a vector index for entity embeddings."""
    fulltext_stmts = [
        "CALL db.index.fulltext.createNodeIndex('entityText', ['Entity'], ['name'])",
        "CALL db.index.fulltext.createNodeIndex('chunkText', ['Chunk'], ['text'])",
        "CALL db.index.fulltext.createNodeIndex('problemText', ['Problem'], ['question'])",
    ]
    with driver.session() as s:
        for st in fulltext_stmts:
            try:
                s.run(st)
            except Exception:
                pass

    # Vector index on Entity nodes for semantic graph search
    vector_stmts = [
        """
        CREATE VECTOR INDEX entity_embedding IF NOT EXISTS
        FOR (e:Entity) ON (e.embedding)
        OPTIONS {indexConfig: {
            `vector.dimensions`: 1536,
            `vector.similarity_function`: 'cosine'
        }}
        """,
        """
        CREATE VECTOR INDEX chunk_embedding IF NOT EXISTS
        FOR (c:Chunk) ON (c.embedding)
        OPTIONS {indexConfig: {
            `vector.dimensions`: 1536,
            `vector.similarity_function`: 'cosine'
        }}
        """,
    ]
    with driver.session() as s:
        for st in vector_stmts:
            try:
                s.run(st)
            except Exception:
                pass


def upsert_neo4j_problem(driver, qid: str, question: str, split: str, image_path: str, answer_idx: int) -> None:
    with driver.session() as s:
        s.run(
            """
            MERGE (p:Problem {qid:$qid})
            SET p.question=$question, p.split=$split, p.image_path=$image_path, p.answer_idx=$answer_idx
            """,
            qid=qid,
            question=question,
            split=split,
            image_path=image_path,
            answer_idx=answer_idx,
        )


def upsert_neo4j_chunk(driver, qid: str, chunk_id: str, chunk_text: str, source: str,
                        embedding: Optional[List[float]] = None) -> None:
    with driver.session() as s:
        s.run(
            """
            MATCH (p:Problem {qid:$qid})
            MERGE (c:Chunk {chunk_id:$chunk_id})
            SET c.text=$text, c.source=$source, c.embedding=$embedding
            MERGE (p)-[:HAS_CHUNK]->(c)
            """,
            qid=qid,
            chunk_id=chunk_id,
            text=chunk_text,
            source=source,
            embedding=embedding,
        )


def upsert_neo4j_kg(driver, qid: str, entities: List[str], relations: List[Tuple[str, str, str]],
                     entity_embeddings: Optional[Dict[str, List[float]]] = None) -> None:
    """Upsert entities and relations into Neo4j with optional vector embeddings."""
    if entity_embeddings is None:
        entity_embeddings = {}
    with driver.session() as s:
        for e in entities:
            emb = entity_embeddings.get(e)
            s.run(
                """
                MATCH (p:Problem {qid:$qid})
                MERGE (ent:Entity {name:$name})
                SET ent.embedding = $embedding
                MERGE (p)-[:MENTIONS]->(ent)
                """,
                qid=qid,
                name=e,
                embedding=emb,
            )
        for h, r, t in relations:
            rel = re.sub(r"[^A-Za-z0-9_]", "_", (r or "").strip())[:32] or "RELATED_TO"
            s.run(
                f"""
                MERGE (h:Entity {{name:$h}})
                MERGE (t:Entity {{name:$t}})
                MERGE (h)-[:{rel}]->(t)
                """,
                h=h,
                t=t,
            )


def _resolve_image_path(image_root: str, split: str, qid: str, image_name: str) -> str:
    """Resolve the image path for a ScienceQA problem.

    ScienceQA structure:
        <image_root>/<split>/<qid>/image.png
    OR  <image_root>/train/<qid>/image.png  (all in one root)

    Returns the path if found, else empty string.
    """
    if not image_name:
        return ""

    # Primary: <image_root>/<split>/<qid>/<image_name>
    candidate = Path(image_root) / split / qid / image_name
    if candidate.exists():
        return str(candidate)

    # Fallback: <image_root>/<qid>/<image_name> (flat structure)
    candidate = Path(image_root) / qid / image_name
    if candidate.exists():
        return str(candidate)

    # Fallback: try all splits
    for s in ["train", "val", "test"]:
        candidate = Path(image_root) / s / qid / image_name
        if candidate.exists():
            return str(candidate)

    return ""


def build_fused_text(problem: Dict, options: List[str], vision_text: str) -> str:
    q = problem.get("question", "")
    hint = problem.get("hint", "")
    cap = problem.get("caption", "")
    choices = problem.get("choices", [])
    choice_txt = " ".join([f"({options[i]}) {c}" for i, c in enumerate(choices)])
    parts = [
        f"Question: {q}",
        f"Hint: {hint}" if hint else "",
        f"Caption: {cap}" if cap else "",
        f"Image-derived evidence: {vision_text}" if vision_text else "",
        f"Options: {choice_txt}" if choice_txt else "",
    ]
    return "\n".join([p for p in parts if p]).strip()


def ingest_dataset(
    problems_path: str,
    image_root: str,
    split: str,
    qdrant_client: QdrantClient,
    qdrant_collection: str,
    neo4j_driver,
    openai_api_key: str,
    embedding_model: str,
    chunk_size: int,
    chunk_overlap: int,
    options: List[str],
    use_vlm: bool,
    vlm_provider: str,
    vlm_model: str,
    hf_endpoint_url: Optional[str],
    hf_token: Optional[str],
    kg_model: str,
    max_items: Optional[int],
) -> None:
    with open(problems_path, "r", encoding="utf-8") as f:
        problems = json.load(f)

    # Filter to requested split first, then apply max_items
    qids = [qid for qid, p in problems.items() if p.get("split", split) == split]
    if max_items:
        qids = qids[:max_items]

    print(f"[ingest] Found {len(qids)} problems for split='{split}'"
          f"{f' (capped to {max_items})' if max_items else ''}")

    # Determine embedding size by one call
    test_vec = embed_texts_openai(["ping"], embedding_model, openai_api_key, batch_size=1)[0]
    vec_size = len(test_vec)
    ensure_qdrant_collection(qdrant_client, qdrant_collection, vector_size=vec_size)
    ensure_neo4j_indexes(neo4j_driver)

    # Pre-load Qwen-VL if needed (so we only load once)
    if use_vlm and vlm_provider == "qwen":
        print("[ingest] Pre-loading Qwen-VL model ...")
        from hmrag_full.vlm_qwen import _load_qwen_vl
        _load_qwen_vl(vlm_model)

    points: List[qmodels.PointStruct] = []
    stats = {"total": 0, "with_image": 0, "vlm_success": 0, "kg_extracted": 0}

    for qid in tqdm(qids, desc=f"Ingest {split}"):
        p = problems[qid]
        stats["total"] += 1

        question = p.get("question", "")
        caption = p.get("caption", "")
        hint = p.get("hint", "")
        answer_idx = int(p.get("answer", 0))
        image_name = p.get("image", "")

        # Resolve image path using the actual ScienceQA directory structure
        img_path = _resolve_image_path(image_root, split, qid, image_name)
        if img_path:
            stats["with_image"] += 1

        upsert_neo4j_problem(neo4j_driver, qid, question, split, img_path, answer_idx)

        # ---- VLM: Extract text from image ----
        vision_text = ""
        if use_vlm and img_path:
            try:
                if vlm_provider == "qwen":
                    vision_text = describe_image_qwen(
                        img_path,
                        question=question,
                        hint=hint,
                        caption=caption,
                        model_name=vlm_model,
                    )
                elif vlm_provider == "openai":
                    vision_text = describe_image_openai(
                        img_path,
                        question=question,
                        hint=hint,
                        caption=caption,
                        model=vlm_model,
                        api_key=openai_api_key,
                    )
                elif vlm_provider == "hf_endpoint":
                    if not hf_endpoint_url or not hf_token:
                        raise ValueError("HF endpoint selected but HF_ENDPOINT_URL / HF_TOKEN not provided")
                    vision_text = describe_image_hf_endpoint(
                        img_path,
                        question=question,
                        hint=hint,
                        caption=caption,
                        endpoint_url=hf_endpoint_url,
                        hf_token=hf_token,
                    )

                if vision_text:
                    stats["vlm_success"] += 1
                    tqdm.write(f"  [VLM] qid={qid}: {vision_text[:80]}...")
            except Exception as e:
                tqdm.write(f"  [VLM ERROR] qid={qid}: {e}")

        # ---- Build fused text (question + hint + caption + VLM output) ----
        fused = build_fused_text(p, options, vision_text)
        chunks = chunk_text(fused, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        if not chunks:
            continue

        # ---- Embed chunks ----
        vecs = embed_texts_openai(chunks, embedding_model, openai_api_key)
        for i, (ch, vec) in enumerate(zip(chunks, vecs)):
            cid = _stable_chunk_id(qid, i, ch)  # String ID for Neo4j
            point_id = _chunk_id_to_uuid(cid)    # UUID for Qdrant
            
            payload = {
                "qid": qid,
                "split": split,
                "chunk_id": cid,  # Keep string ID in payload for reference
                "chunk_index": i,
                "question": question,
                "text": ch,
                "image_path": img_path,
                "vision_text": vision_text,
                "answer_idx": answer_idx,
                "choices": p.get("choices", []),
            }
            
            # Use UUID for Qdrant point ID
            points.append(qmodels.PointStruct(id=point_id, vector=vec, payload=payload))
            
            # Also store chunk embedding in Neo4j for hybrid graph+vector search
            upsert_neo4j_chunk(neo4j_driver, qid, cid, ch, source="fused", embedding=vec)

        # ---- MMKG: extract entities/relations ----
        kg = extract_kg_openai(fused_text=fused, model=kg_model, api_key=openai_api_key)
        if kg.entities or kg.relations:
            stats["kg_extracted"] += 1
            # Embed entity names for vector index on Neo4j
            entity_names = list(set(kg.entities))
            if entity_names:
                ent_vecs = embed_texts_openai(entity_names, embedding_model, openai_api_key)
                entity_embeddings = dict(zip(entity_names, ent_vecs))
            else:
                entity_embeddings = {}
            upsert_neo4j_kg(neo4j_driver, qid, kg.entities, kg.relations,
                            entity_embeddings=entity_embeddings)

        # flush periodically
        if len(points) >= 128:
            qdrant_client.upsert(collection_name=qdrant_collection, points=points)
            points = []

    if points:
        qdrant_client.upsert(collection_name=qdrant_collection, points=points)

    print(f"\n[ingest] Done. Stats: {stats}")


def main():
    parser = argparse.ArgumentParser(description="MMKG-style ingestion for HM-RAG with Qwen-VL support")

    parser.add_argument("--dataset", required=True, help="Path to problems.json from ScienceQA.")
    parser.add_argument("--image-root", required=True,
                        help="Root directory containing train/val/test folders with images. "
                             "e.g. /content/ScienceQA/data/scienceqa")
    parser.add_argument("--split", default="test", help="Which split to ingest: train/val/test")
    parser.add_argument("--max-items", type=int, default=None, help="Debug: ingest only first N items")

    parser.add_argument("--qdrant-host", default="localhost")
    parser.add_argument("--qdrant-port", type=int, default=6333)
    parser.add_argument("--qdrant-api-key", default=None)
    parser.add_argument("--qdrant-collection", default="hmrag_collection")
    parser.add_argument("--qdrant-https", action="store_true", help="Use HTTPS when connecting to Qdrant")

    parser.add_argument("--neo4j-uri", default="bolt://localhost:7687")
    parser.add_argument("--neo4j-user", default="neo4j")
    parser.add_argument("--neo4j-password", default="password")

    parser.add_argument("--openai-api-key", required=True)
    parser.add_argument("--embedding-model", default="text-embedding-3-small")
    parser.add_argument("--chunk-size", type=int, default=800)
    parser.add_argument("--chunk-overlap", type=int, default=100)

    parser.add_argument("--use-vlm", action="store_true", help="Run VLM image->text during ingestion")
    parser.add_argument("--vlm-provider", choices=["openai", "hf_endpoint", "qwen"], default="qwen",
                        help="VLM provider: 'qwen' for local Qwen-VL, 'openai' for GPT-4V, 'hf_endpoint'")
    parser.add_argument("--vlm-model", default="Qwen/Qwen2.5-VL-3B-Instruct",
                        help="Model name. For qwen: HF model ID. For openai: model name like gpt-4o-mini")
    parser.add_argument("--hf-endpoint-url", default=None)
    parser.add_argument("--hf-token", default=None)

    parser.add_argument("--kg-model", default="gpt-4o-mini", help="LLM used for entity/relation extraction")

    args = parser.parse_args()

    qdrant_client = QdrantClient(
        host=args.qdrant_host,
        port=args.qdrant_port,
        api_key=args.qdrant_api_key,
        https=args.qdrant_https,
        timeout=60,
    )
    neo4j_driver = GraphDatabase.driver(args.neo4j_uri, auth=(args.neo4j_user, args.neo4j_password))

    # ScienceQA standard options are A..E
    options = ["A", "B", "C", "D", "E"]

    ingest_dataset(
        problems_path=args.dataset,
        image_root=args.image_root,
        split=args.split,
        qdrant_client=qdrant_client,
        qdrant_collection=args.qdrant_collection,
        neo4j_driver=neo4j_driver,
        openai_api_key=args.openai_api_key,
        embedding_model=args.embedding_model,
        chunk_size=args.chunk_size,
        chunk_overlap=args.chunk_overlap,
        options=options,
        use_vlm=args.use_vlm,
        vlm_provider=args.vlm_provider,
        vlm_model=args.vlm_model,
        hf_endpoint_url=args.hf_endpoint_url,
        hf_token=args.hf_token,
        kg_model=args.kg_model,
        max_items=args.max_items,
    )

    neo4j_driver.close()


if __name__ == "__main__":
    main()
