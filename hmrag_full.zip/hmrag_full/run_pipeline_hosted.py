"""Run the HM-RAG pipeline using hosted models (Colab-friendly).

This avoids Ollama + local Qwen weights and instead uses OpenAI models:
 - Decomposition: gpt-4o-mini
 - Fusion/summary: gpt-4o-mini (optionally with image input)

Retrieval still uses Qdrant (vector), Neo4j (graph) and Serper (web).
"""

import argparse
import json

from .config import Config
from .multi_retrieval_agent_hosted import MRetrievalAgentHosted


def load_problems(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True, help="Path to ScienceQA problems.json")
    parser.add_argument("--qid", required=True)
    parser.add_argument("--shot-qids", nargs="*", default=[])

    parser.add_argument("--qdrant-host", default="localhost")
    parser.add_argument("--qdrant-port", type=int, default=6333)
    parser.add_argument("--qdrant-api-key", default=None)
    parser.add_argument("--qdrant-collection", default="hmrag_collection")
    parser.add_argument("--qdrant-https", action="store_true")
    parser.add_argument("--qdrant-url", default=None)

    parser.add_argument("--neo4j-uri", default="bolt://localhost:7687")
    parser.add_argument("--neo4j-user", default="neo4j")
    parser.add_argument("--neo4j-password", default="password")

    parser.add_argument("--serper-api-key", default=None)
    parser.add_argument("--openai-api-key", required=True)

    parser.add_argument("--image-root", default=None, help="ScienceQA image root (needed for VLM on images)")
    parser.add_argument("--top-k", type=int, default=5)

    args = parser.parse_args()

    import time
    t_start = time.time()

    print("\n" + "█"*80)
    print("█" + " HM-RAG PIPELINE START ".center(78) + "█")
    print("█"*80)
    print(f"  Dataset:    {args.dataset}")
    print(f"  QID:        {args.qid}")
    print(f"  Shot QIDs:  {args.shot_qids or '(none)'}")
    print(f"  Qdrant:     {args.qdrant_host}:{args.qdrant_port}")
    print(f"  Neo4j:      {args.neo4j_uri}")
    print(f"  Serper:     {'configured' if args.serper_api_key else 'NOT configured'}")
    print(f"  Image root: {args.image_root or '(not set)'}")
    print(f"  Top-K:      {args.top_k}")

    problems = load_problems(args.dataset)
    print(f"\n  📂 Loaded {len(problems)} problems from dataset")

    qid = args.qid
    if qid in problems:
        p = problems[qid]
        print(f"  📋 Problem {qid}:")
        print(f"     Question: {p.get('question', '')}")
        print(f"     Choices:  {p.get('choices', [])}")
        print(f"     Hint:     {p.get('hint', '') or '(none)'}")
        print(f"     Image:    {p.get('image', '') or '(none)'}")
        print(f"     Split:    {p.get('split', '?')}")
        print(f"     GT Answer: {p.get('answer', '?')}")
    else:
        print(f"  ⚠ QID {qid} not found in dataset!")

    cfg = Config(
        qdrant_host=args.qdrant_host,
        qdrant_port=args.qdrant_port,
        qdrant_api_key=args.qdrant_api_key,
        qdrant_collection=args.qdrant_collection,
        qdrant_https=args.qdrant_https,
        qdrant_url=args.qdrant_url,
        vector_top_k=args.top_k,
        neo4j_uri=args.neo4j_uri,
        neo4j_user=args.neo4j_user,
        neo4j_password=args.neo4j_password,
        graph_top_k=args.top_k,
        serper_api_key=args.serper_api_key,
        serper_top_k=args.top_k,
        openai_api_key=args.openai_api_key,
        embedding_model_name="text-embedding-3-small",
        image_root=args.image_root or getattr(args, "image_root", None) or "",
    )

    print("\n  ⚙️  Initializing agents ...")
    agent = MRetrievalAgentHosted(cfg)
    print("  ✓ All agents initialized")

    pred_idx, messages = agent.predict(problems, args.shot_qids, args.qid)

    elapsed = time.time() - t_start

    print("\n" + "█"*80)
    print("█" + " HM-RAG PIPELINE COMPLETE ".center(78) + "█")
    print("█"*80)
    print(f"  ⏱  Total time: {elapsed:.2f}s")
    print(f"  🎯 Predicted answer index: {pred_idx}")
    if qid in problems:
        choices = problems[qid].get('choices', [])
        gt = problems[qid].get('answer', '?')
        if isinstance(pred_idx, int) and pred_idx < len(choices):
            print(f"  🎯 Predicted answer: {choices[pred_idx]}")
        print(f"  ✅ Ground truth:     {gt}")
        if isinstance(gt, int) and gt < len(choices):
            print(f"  ✅ Ground truth:     {choices[gt]}")
        if pred_idx == gt:
            print(f"  🟢 CORRECT!")
        else:
            print(f"  🔴 INCORRECT!")
    print("█"*80 + "\n")


if __name__ == "__main__":
    main()
