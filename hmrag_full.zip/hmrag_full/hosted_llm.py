"""Small wrappers around hosted LLM/VLM calls.

We keep the original HM-RAG agents intact (which use Ollama + local
weights). For Colab/CPU or no-GPU setups, use the hosted variants
provided in *_hosted.py.
"""

import base64
import os
from typing import Optional


def _b64_data_url(image_path: str) -> str:
    ext = os.path.splitext(image_path)[1].lower().lstrip(".")
    if ext in ("jpg", "jpeg"):
        mime = "image/jpeg"
    elif ext == "webp":
        mime = "image/webp"
    elif ext == "gif":
        mime = "image/gif"
    else:
        mime = "image/png"
    with open(image_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    return f"data:{mime};base64,{b64}"


def openai_text(
    prompt: str,
    api_key: str,
    model: str = "gpt-4o-mini",
    temperature: float = 0.2,
    system: Optional[str] = None,
) -> str:
    from openai import OpenAI
    import time

    print(f"     ╭─ OpenAI TEXT API call ─────────────────────────╮")
    print(f"     │ Model: {model:<42} │")
    print(f"     │ Temperature: {temperature:<37} │")
    print(f"     │ Prompt length: {len(prompt):<35} │")
    if system:
        print(f"     │ System prompt: {system[:35]:<35} │")
    print(f"     ╰──────────────────────────────────────────────────╯")

    client = OpenAI(api_key=api_key)
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    t0 = time.time()
    resp = client.chat.completions.create(model=model, messages=messages, temperature=temperature)
    elapsed = time.time() - t0
    result = (resp.choices[0].message.content or "").strip()
    usage = resp.usage
    print(f"     ╭─ OpenAI TEXT response ────────────────────────╮")
    print(f"     │ Time: {elapsed:.2f}s{' '*(39-len(f'{elapsed:.2f}s'))} │")
    if usage:
        print(f"     │ Tokens: prompt={usage.prompt_tokens} completion={usage.completion_tokens} total={usage.total_tokens} │")
    print(f"     │ Response length: {len(result):<34} │")
    print(f"     ╰──────────────────────────────────────────────────╯")
    return result


def openai_vision(
    prompt: str,
    image_path: str,
    api_key: str,
    model: str = "gpt-4o-mini",
    temperature: float = 0.2,
    system: Optional[str] = None,
) -> str:
    from openai import OpenAI
    import time

    print(f"     ╭─ OpenAI VISION API call ──────────────────────╮")
    print(f"     │ Model: {model:<42} │")
    print(f"     │ Temperature: {temperature:<37} │")
    print(f"     │ Prompt length: {len(prompt):<35} │")
    print(f"     │ Image: {image_path[-40:]:<42} │")
    if system:
        print(f"     │ System prompt: {system[:35]:<35} │")
    print(f"     ╰──────────────────────────────────────────────────╯")

    client = OpenAI(api_key=api_key)
    img_url = _b64_data_url(image_path)
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append(
        {
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": img_url}},
            ],
        }
    )
    t0 = time.time()
    resp = client.chat.completions.create(model=model, messages=messages, temperature=temperature)
    elapsed = time.time() - t0
    result = (resp.choices[0].message.content or "").strip()
    usage = resp.usage
    print(f"     ╭─ OpenAI VISION response ──────────────────────╮")
    print(f"     │ Time: {elapsed:.2f}s{' '*(39-len(f'{elapsed:.2f}s'))} │")
    if usage:
        print(f"     │ Tokens: prompt={usage.prompt_tokens} completion={usage.completion_tokens} total={usage.total_tokens} │")
    print(f"     │ Response length: {len(result):<34} │")
    print(f"     ╰──────────────────────────────────────────────────╯")
    return result
