"""
Base model abstraction for ScienceQA/HM‑RAG.

This file defines a minimal ``BaseModel`` class used in the original
ScienceQA codebase.  It provides helper methods for composing
multi‑modal messages (text and images) and a placeholder ``predict``
method to be implemented by subclasses.  The implementation here is
unchanged from the version provided by the user except for this
docstring.
"""

import torch


class BaseModel:
    def __init__(self, config) -> None:
        """
        Base model constructor to initialise common attributes.

        Parameters
        ----------
        config : object
            A configuration object containing model parameters.
        """
        self.config = config

    def predict(self, question, texts=None, images=None, history=None):
        """Placeholder predict method to be overridden by subclasses."""
        pass

    def clean_up(self) -> None:
        """Free up GPU memory."""
        torch.cuda.empty_cache()

    def process_message(self, question, texts, images, history):
        if history is not None:
            assert self.is_valid_history(history)
            messages = history
        else:
            messages = []

        if texts is not None:
            messages.append(self.create_text_message(texts, question))
        if images is not None:
            messages.append(self.create_image_message(images, question))

        if (texts is None or len(texts) == 0) and (images is None or len(images) == 0):
            messages.append(self.create_ask_message(question))

        return messages

    def is_valid_history(self, history) -> bool:
        return True