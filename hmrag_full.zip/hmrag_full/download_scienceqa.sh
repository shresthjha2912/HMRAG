#!/bin/bash
# Script to download the ScienceQA dataset.
#
# This helper script clones the official ScienceQA repository and runs
# its download script.  The file is provided for completeness; you may
# choose to use it to obtain the dataset before ingestion.

set -e

git clone https://github.com/lupantech/ScienceQA

cd ScienceQA

bash tools/download.sh