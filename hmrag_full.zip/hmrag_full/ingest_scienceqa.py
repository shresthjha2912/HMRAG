"""
Ingestion script for ScienceQA dataset (nested version).

This script reads the ScienceQA problems JSON file and populates a
Qdrant vector database and a Neo4j graph database with the contents.
It is a direct copy of the top‑level ``ingest_scienceqa.py`` to allow
the ``hmrag_full`` folder to operate as a self‑contained package when
zipped.  See the original file for detailed documentation.
"""

import argparse
import json
import hashlib
from typing import List

from qdrant_client import QdrantClient
from qdrant_client.http.models import VectorParams, Distance, PointStruct
from neo4j import GraphDatabase

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None  # type: ignore


def chunk_text(text: str, chunk_size: int = 500, chunk_overlap: int = 50) -> List[str]:
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start += chunk_size - chunk_overlap
    return chunks


def embed_texts(texts: List[str], model_name: str, api_key: str) -> List[List[float]]:
    if OpenAI is None:
        raise ImportError("openai>=1.0.0 is required. Install with: pip install -U openai")
    client = OpenAI(api_key=api_key)
    resp = client.embeddings.create(model=model_name, input=texts, encoding_format="float")
    return [d.embedding for d in resp.data]


def ingest_dataset(
    dataset_path: str,
    qdrant_client: QdrantClient,
    qdrant_collection: str,
    neo4j_driver,
    embedding_model: str,
    openai_api_key: str,
    chunk_size: int = 500,
    chunk_overlap: int = 50,
) -> None:
    with open(dataset_path, "r", encoding="utf-8") as f:
        problems = json.load(f)
    existing = [c.name for c in qdrant_client.get_collections().collections]
    if qdrant_collection not in existing:
        print(f"Collection '{qdrant_collection}' does not exist; it will be created on first insert.")
    for qid, prob in problems.items():
        question = prob.get("question", "")
        hint = prob.get("hint", "") or prob.get("context", "")
        caption = prob.get("caption", "")
        choices = prob.get("choices", [])
        answer_idx = prob.get("answer")
        choice_text = " ".join(choices)
        full_text = " ".join([question, hint, caption, choice_text]).strip()
        chunks = chunk_text(full_text, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        if not chunks:
            chunks = [full_text]
        embeddings = embed_texts(chunks, embedding_model, openai_api_key)
        if qdrant_collection not in existing:
            dim = len(embeddings[0])
            qdrant_client.create_collection(
                collection_name=qdrant_collection,
                vectors_config=VectorParams(size=dim, distance=Distance.COSINE),
            )
            existing.append(qdrant_collection)
        qdrant_points = []
        for idx, (chunk, embed) in enumerate(zip(chunks, embeddings)):
            payload = {
                "doc_id": qid,
                "chunk_index": idx,
                "text": chunk,
                "question": question,
            }
            pid = int(hashlib.md5(f"{qid}::{idx}".encode()).hexdigest(), 16) % (2 ** 63)
            qdrant_points.append(PointStruct(id=pid, vector=embed, payload=payload))
        qdrant_client.upsert(collection_name=qdrant_collection, points=qdrant_points)
        with neo4j_driver.session() as session:
            session.run(
                """
                MERGE (d:Document {id: $qid})
                SET d.question = $question,
                    d.hint = $hint,
                    d.caption = $caption
                """,
                {"qid": qid, "question": question, "hint": hint, "caption": caption},
            )
            options = ["A", "B", "C", "D", "E"]
            for i, choice in enumerate(choices):
                if i >= len(options):
                    break
                label = options[i]
                cid = f"{qid}_{label}"
                session.run(
                    """
                    MERGE (c:Choice {id: $cid})
                    SET c.label = $label,
                        c.text = $text
                    """,
                    {"cid": cid, "label": label, "text": choice},
                )
                session.run(
                    """
                    MATCH (d:Document {id: $qid}), (c:Choice {id: $cid})
                    MERGE (d)-[:HAS_CHOICE]->(c)
                    """,
                    {"qid": qid, "cid": cid},
                )
            if answer_idx is not None and 0 <= answer_idx < len(choices):
                ans_label = options[answer_idx]
                ans_text = choices[answer_idx]
                aid = f"{qid}_answer"
                session.run(
                    """
                    MERGE (a:Answer {id: $aid})
                    SET a.label = $label,
                        a.text = $text
                    """,
                    {"aid": aid, "label": ans_label, "text": ans_text},
                )
                session.run(
                    """
                    MATCH (d:Document {id: $qid}), (a:Answer {id: $aid})
                    MERGE (d)-[:HAS_ANSWER]->(a)
                    """,
                    {"qid": qid, "aid": aid},
                )
        print(f"Ingested problem {qid} with {len(chunks)} chunks")


def main() -> None:
    parser = argparse.ArgumentParser(description="Ingest ScienceQA dataset into Qdrant and Neo4j.")
    parser.add_argument("--dataset", required=True, help="Path to problems.json from ScienceQA.")
    parser.add_argument("--qdrant-host", default="localhost", help="Qdrant host.")
    parser.add_argument("--qdrant-port", type=int, default=6333, help="Qdrant port.")
    parser.add_argument("--qdrant-api-key", default=None, help="Qdrant API key.")
    parser.add_argument("--qdrant-https", action="store_true", help="Use HTTPS (Qdrant Cloud).")
    parser.add_argument("--qdrant-url", default=None, help="Full Qdrant URL (overrides host/port).")
    parser.add_argument("--qdrant-collection", default="hmrag_collection", help="Collection name in Qdrant.")
    parser.add_argument("--neo4j-uri", default="bolt://localhost:7687", help="Neo4j URI.")
    parser.add_argument("--neo4j-user", default="neo4j", help="Neo4j username.")
    parser.add_argument("--neo4j-password", default="password", help="Neo4j password.")
    parser.add_argument("--openai-api-key", required=True, help="OpenAI API key for embeddings.")
    parser.add_argument("--embedding-model", default="text-embedding-3-small", help="OpenAI embedding model.")
    parser.add_argument("--chunk-size", type=int, default=500, help="Character length of each chunk.")
    parser.add_argument("--chunk-overlap", type=int, default=50, help="Overlap between consecutive chunks.")
    args = parser.parse_args()
    if args.qdrant_url:
        qdrant_url = str(args.qdrant_url)
    else:
        if str(args.qdrant_host).startswith("http://") or str(args.qdrant_host).startswith("https://"):
            qdrant_url = str(args.qdrant_host)
        else:
            scheme = "https" if args.qdrant_https else "http"
            qdrant_url = f"{scheme}://{args.qdrant_host}:{args.qdrant_port}"
    qdrant_client = QdrantClient(url=qdrant_url, api_key=args.qdrant_api_key)
    neo4j_driver = GraphDatabase.driver(args.neo4j_uri, auth=(args.neo4j_user, args.neo4j_password))
    ingest_dataset(
        dataset_path=args.dataset,
        qdrant_client=qdrant_client,
        qdrant_collection=args.qdrant_collection,
        neo4j_driver=neo4j_driver,
        embedding_model=args.embedding_model,
        openai_api_key=args.openai_api_key,
        chunk_size=args.chunk_size,
        chunk_overlap=args.chunk_overlap,
    )


if __name__ == "__main__":
    main()