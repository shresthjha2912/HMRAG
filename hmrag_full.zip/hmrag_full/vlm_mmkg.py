import base64
import json
import os
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import requests


def _extract_first_json(text: str) -> Dict:
    """Extract the first JSON object found in `text` (best-effort)."""
    if not text:
        return {}
    # Remove common Markdown fences.
    text = re.sub(r"```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = text.replace("```", "")
    # Try direct parse first.
    try:
        return json.loads(text)
    except Exception:
        pass

    # Try to locate the first {...} block.
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(text[start : end + 1])
        except Exception:
            return {}
    return {}


def _b64_image_data_url(image_path: str) -> str:
    """Return a data URL for an image file."""
    ext = os.path.splitext(image_path)[1].lower().lstrip(".")
    if ext in ("jpg", "jpeg"):
        mime = "image/jpeg"
    elif ext == "webp":
        mime = "image/webp"
    elif ext == "gif":
        mime = "image/gif"
    else:
        mime = "image/png"

    with open(image_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    return f"data:{mime};base64,{b64}"


@dataclass
class KGExtract:
    entities: List[str]
    relations: List[Tuple[str, str, str]]  # (head, relation, tail)


def describe_image_openai(
    image_path: str,
    question: str,
    hint: str = "",
    caption: str = "",
    model: str = "gpt-4o-mini",
    api_key: Optional[str] = None,
) -> str:
    """Create a grounded description of the image using a hosted VLM (OpenAI).

    Uses the Chat Completions API with an image input.
    """
    from openai import OpenAI

    client = OpenAI(api_key=api_key)
    img_url = _b64_image_data_url(image_path)

    sys = (
        "You are a vision-language assistant. Describe the image precisely, "
        "including any visible text (OCR), objects, relations, and quantities. "
        "Keep it factual; do not guess beyond the image."
    )
    user_txt = (
        f"Question: {question}\n"
        f"Hint: {hint}\n"
        f"Provided caption (may be noisy): {caption}\n\n"
        "Task: Write a concise but information-dense description of the image "
        "that would help answer the question."
    )

    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": sys},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_txt},
                    {"type": "image_url", "image_url": {"url": img_url}},
                ],
            },
        ],
        temperature=0.2,
    )
    return (resp.choices[0].message.content or "").strip()


def describe_image_hf_endpoint(
    image_path: str,
    question: str,
    endpoint_url: str,
    hf_token: str,
    hint: str = "",
    caption: str = "",
) -> str:
    """Describe image via a Hugging Face *dedicated* endpoint.

    This is intentionally generic because HF endpoints can be configured
    with different input schemas. Many VLM endpoints accept JSON with
    fields like {"inputs": {"text": ..., "image": ...}}.

    You may need to adjust payload format to match your endpoint.
    """
    img_url = _b64_image_data_url(image_path)
    prompt = (
        f"Question: {question}\nHint: {hint}\nCaption: {caption}\n\n"
        "Describe the image precisely including visible text."
    )

    headers = {"Authorization": f"Bearer {hf_token}", "Content-Type": "application/json"}
    payload = {"inputs": {"text": prompt, "image": img_url}}
    r = requests.post(endpoint_url, headers=headers, json=payload, timeout=180)
    r.raise_for_status()
    data = r.json()
    # Heuristic: endpoints often return {"generated_text": ...} or a list.
    if isinstance(data, dict):
        return (data.get("generated_text") or data.get("text") or json.dumps(data))
    if isinstance(data, list) and data:
        if isinstance(data[0], dict):
            return (data[0].get("generated_text") or data[0].get("text") or json.dumps(data[0]))
        return str(data[0])
    return str(data)


def extract_kg_openai(
    fused_text: str,
    model: str = "gpt-4o-mini",
    api_key: Optional[str] = None,
) -> KGExtract:
    """Extract entities + relations from text using a hosted LLM.

    Output is constrained JSON:
    {
      "entities": ["..."],
      "relations": [{"head": "...", "relation": "...", "tail": "..."}]
    }
    """
    from openai import OpenAI

    client = OpenAI(api_key=api_key)
    sys = (
        "You extract a lightweight knowledge graph from evidence text. "
        "Return ONLY JSON with keys: entities (list[str]) and relations (list)."
    )
    user = (
        "Extract key named entities and scientific concepts, then relations between them. "
        "Use short relation labels (e.g., 'causes', 'part_of', 'located_in', 'requires', 'has'). "
        "If unsure, omit.\n\n"
        f"TEXT:\n{fused_text}\n"
    )

    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": sys},
            {"role": "user", "content": user},
        ],
        temperature=0.0,
    )
    raw = (resp.choices[0].message.content or "").strip()
    obj = _extract_first_json(raw)
    ents = [e.strip() for e in (obj.get("entities") or []) if isinstance(e, str) and e.strip()]
    rels_in = obj.get("relations") or []
    rels: List[Tuple[str, str, str]] = []
    if isinstance(rels_in, list):
        for it in rels_in:
            if not isinstance(it, dict):
                continue
            h = str(it.get("head") or "").strip()
            r = str(it.get("relation") or "").strip()
            t = str(it.get("tail") or "").strip()
            if h and r and t:
                rels.append((h, r, t))
    # De-dup while preserving order
    seen = set()
    ents2 = []
    for e in ents:
        key = e.lower()
        if key not in seen:
            ents2.append(e)
            seen.add(key)
    return KGExtract(entities=ents2, relations=rels)
