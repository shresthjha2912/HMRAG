"""HM‑RAG stand‑alone package.

This package contains a self‑contained copy of the key components
required to run the HM‑RAG pipeline as described in the user prompt.
It exposes the retrieval agents, decomposition agent, summarisation
agent, configuration definitions and utility functions.  To use the
pipeline, import the ``config.Config`` class, build a
``multi_retrieval_agent.MRetrievalAgent`` with your configuration and
call its ``predict`` method.
"""