import os
import random
import re
from typing import Any, List, Tuple

from .hosted_llm import openai_text, openai_vision
from .prompts import build_prompt


class SummaryAgentHosted:
    """Hosted summariser + answer fuser.

    Keeps the prompt format from prompts.py but runs inference on a hosted
    model (no local weights/Ollama required).
    """

    def __init__(self, config: Any):
        self.config = config
        self.api_key = getattr(config, "openai_api_key", None)
        self.text_model = getattr(config, "summary_text_model", "gpt-4o-mini")
        self.vision_model = getattr(config, "summary_vision_model", "gpt-4o-mini")

    def _get_result_letter(self, output: str) -> str:
        # Try exact pattern first
        m = re.search(r"[Tt]he answer is\s+([A-Ea-e])", output)
        if m:
            return m.group(1).upper()
        # Fallback: look for standalone answer letter after "Answer:"
        m2 = re.search(r"Answer:\s*([A-Ea-e])\b", output)
        if m2:
            return m2.group(1).upper()
        return "FAILED"

    def _pred_idx(self, letter: str, choices: List[str], options: List[str]) -> int:
        if letter in options[: len(choices)]:
            return options.index(letter)
        return random.choice(range(len(choices)))

    def summarize(self, problems, shot_qids, qid, cur_ans) -> Tuple[int, Any]:
        prob = problems[qid]
        question = prob["question"]
        choices = prob["choices"]
        split = prob.get("split", "test")
        image = prob.get("image", "")

        print("\n" + "─"*60)
        print("📝 SUMMARY AGENT ─ Building final answer")
        print("─"*60)
        print(f"  Question: {question}")
        print(f"  Choices:  {choices}")
        print(f"  Split:    {split}")
        print(f"  Image:    {image or '(none)'}")
        print(f"  Few-shot QIDs: {shot_qids if shot_qids else '(none)'}")

        # Base ScienceQA few-shot prompt
        print("\n  📄 Building few-shot prompt from prompts.py ...")
        base = build_prompt(problems, shot_qids, qid, self.config)
        print(f"  📄 Base prompt length: {len(base)} chars")
        print(f"  📄 Base prompt preview:\n     {base[:300]}..." if len(base) > 300 else f"  📄 Base prompt:\n     {base}")

        # Attach retrieval outputs
        if isinstance(cur_ans, (list, tuple)):
            joined = "\n\n".join(str(x) for x in cur_ans)
        else:
            joined = str(cur_ans)

        print(f"\n  📚 Attaching retrieved evidence ({len(joined)} chars)")

        prompt = (
            f"{base}\n\n"
            f"Retrieved Evidence:\n{joined}\n\n"
            "Use the evidence to select the best option. "
            "Respond strictly in the format: 'Answer: The answer is X.\nBECAUSE: ...' "
            "where X is A, B, C, D, E, or FAILED."
        )

        print(f"  📝 Final prompt length: {len(prompt)} chars")

        image_path = ""
        if image and getattr(self.config, "image_root", None):
            candidate = os.path.join(self.config.image_root, split, qid, image)
            print(f"  🖼️  Checking for image at: {candidate}")
            if os.path.exists(candidate):
                image_path = candidate
                print(f"  🖼️  ✓ Image found!")
            else:
                print(f"  🖼️  ✗ Image not found at that path")

        if image_path:
            print(f"\n  🤖 Calling VISION model: {self.vision_model}")
            print(f"     (sending image + text prompt)")
            out = openai_vision(prompt, image_path=image_path, api_key=self.api_key, model=self.vision_model)
        else:
            print(f"\n  🤖 Calling TEXT model: {self.text_model}")
            print(f"     (text-only, no image)")
            out = openai_text(prompt, api_key=self.api_key, model=self.text_model)

        print(f"\n  📨 Raw LLM response:")
        print(f"  ┌{'─'*56}┐")
        for line in out.split("\n"):
            print(f"  │ {line:<55}│")
        print(f"  └{'─'*56}┘")

        letter = self._get_result_letter(out)
        print(f"\n  🔤 Extracted answer letter: '{letter}'")

        options = getattr(self.config, "options", ["A", "B", "C", "D", "E"])
        pred_idx = self._pred_idx(letter, choices, options)
        print(f"  🔢 Mapped to index: {pred_idx}")
        if pred_idx < len(choices):
            print(f"  📌 Selected choice: {choices[pred_idx]}")
        if letter == "FAILED":
            print(f"  ⚠ Answer extraction FAILED ─ random fallback used!")

        return pred_idx, cur_ans
