from typing import List

from .hosted_llm import openai_text


class DecomposeAgentHosted:
    """Hosted decomposition agent.

    Original HM-RAG uses Ollama locally. This version uses a hosted
    OpenAI model. Interface is compatible with the caller: .decompose(query)
    returns either a list[str] or a string.
    """

    def __init__(self, config):
        self.config = config
        self.api_key = getattr(config, "openai_api_key", None)
        self.model = getattr(config, "decompose_model", "gpt-4o-mini")
        self.temperature = getattr(config, "decompose_temperature", 0.35)

    def count_intents(self, query: str) -> int:
        print("\n" + "─"*60)
        print("🧩 DECOMPOSE AGENT ─ Counting intents")
        print("─"*60)
        prompt = (
            "Please calculate how many independent intents are contained in the following query. "
            "Return only an integer.\n\n"
            f"Query: {query}\n"
            "Number of intents:"
        )
        print(f"  📝 Intent-counting prompt:\n     {prompt}")
        print(f"  🤖 Calling {self.model} (temp=0.0) ...")
        txt = openai_text(prompt, api_key=self.api_key, model=self.model, temperature=0.0)
        print(f"  📨 Raw LLM response: '{txt.strip()}'")
        try:
            count = int(txt.strip())
            print(f"  ✓ Parsed intent count: {count}")
            return count
        except Exception:
            print(f"  ⚠ Could not parse intent count, defaulting to 1")
            return 1

    def decompose(self, query: str):
        print("\n" + "="*60)
        print("🧩 DECOMPOSE AGENT ─ Starting decomposition")
        print("="*60)
        print(f"  📥 Input query: {query}")
        k = max(1, min(self.count_intents(query), 3))
        print(f"  🔢 Intent count (clamped 1-3): {k}")
        if k <= 1:
            print(f"  ➡ Single intent detected ─ returning original query as-is")
            print(f"  📤 Output: ['{query}']")
            return query
        print(f"  🔀 Multiple intents detected ─ splitting into {k} sub-queries")
        prompt = (
            "Split the following query into multiple independent sub-queries, separated by '||', "
            "without additional explanations.\n\n"
            f"Query: {query}\n"
            "List of sub-queries:"
        )
        print(f"  📝 Decomposition prompt:\n     {prompt}")
        print(f"  🤖 Calling {self.model} (temp={self.temperature}) ...")
        txt = openai_text(prompt, api_key=self.api_key, model=self.model, temperature=self.temperature)
        print(f"  📨 Raw LLM response: '{txt.strip()}'")
        subs = [q.strip() for q in txt.split("||") if q.strip()]
        print(f"  ✓ Parsed {len(subs)} sub-queries:")
        for i, sq in enumerate(subs, 1):
            print(f"     [{i}] {sq}")
        return subs
