"""
Configuration definitions for the stand‑alone HM‑RAG package in hmrag_full.

This dataclass collects all configuration parameters required by the
various components of the HM‑RAG pipeline.  It mirrors the top‑level
configuration to allow the nested package to run independently.  You
can customise the values here or supply your own configuration object
with equivalent attributes when constructing the agents.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Config:
    # Vector DB (Qdrant) configuration
    qdrant_host: str = "localhost"
    qdrant_port: int = 6333
    qdrant_api_key: Optional[str] = None
    # For Qdrant Cloud / HTTPS reverse proxies
    qdrant_https: bool = False
    # Optional: supply full URL (overrides host/port): e.g. "https://xxxx.qdrant.tech"
    qdrant_url: Optional[str] = None
    qdrant_collection: str = "hmrag_collection"
    vector_top_k: int = 5
    score_threshold: Optional[float] = None

    # Graph DB (Neo4j) configuration
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = "password"
    graph_top_k: int = 5

    # Web search (Serper) configuration
    serper_api_key: Optional[str] = None
    serper_top_k: int = 5

    # Embedding configuration
    openai_api_key: Optional[str] = None
    embedding_model_name: str = "text-embedding-3-small"

    # ScienceQA / prompt configuration
    use_caption: bool = False
    options: List[str] = field(default_factory=lambda: ["A", "B", "C", "D", "E"])
    prompt_format: str = "QCM-A"

    # Root directory for ScienceQA images (used by SummaryAgent)
    image_root: str = "./data/images"