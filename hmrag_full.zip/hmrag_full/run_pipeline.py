"""
Demonstration script for the HM‑RAG pipeline in the hmrag_full package.

This script ties together the various agents defined in this
repository (decomposition, retrieval and summarisation) and shows how
to execute a single query against the system.  Before running this
script you should ensure that your Qdrant and Neo4j instances are
running and populated with the appropriate data, and that you have a
Serper API key for web search.  You will also need to download the
ScienceQA dataset or supply your own dataset of similar structure.
"""

import argparse
import json
from typing import List

from config import Config
from multi_retrieval_agent import MRetrievalAgent


def load_problems(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        problems = json.load(f)
    return problems


def main() -> None:
    parser = argparse.ArgumentParser(description="Run HM‑RAG pipeline on a single question.")
    parser.add_argument("--dataset", required=True, help="Path to the ScienceQA problems JSON file.")
    parser.add_argument("--qid", required=True, help="Question ID to evaluate.")
    parser.add_argument("--shot-qids", nargs="*", default=[], help="Optional list of shot question IDs for few‑shot prompting.")
    parser.add_argument("--qdrant-host", default="localhost", help="Qdrant host name.")
    parser.add_argument("--qdrant-port", type=int, default=6333, help="Qdrant port.")
    parser.add_argument("--qdrant-api-key", default=None, help="Qdrant API key (optional).")
    parser.add_argument("--qdrant-collection", default="hmrag_collection", help="Qdrant collection name.")
    parser.add_argument("--neo4j-uri", default="bolt://localhost:7687", help="Neo4j URI.")
    parser.add_argument("--neo4j-user", default="neo4j", help="Neo4j username.")
    parser.add_argument("--neo4j-password", default="password", help="Neo4j password.")
    parser.add_argument("--serper-api-key", default=None, help="Serper API key.")
    parser.add_argument("--openai-api-key", default=None, help="OpenAI API key for embeddings.")
    parser.add_argument("--top-k", type=int, default=5, help="Number of top results to retrieve from each modality.")
    args = parser.parse_args()

    problems = load_problems(args.dataset)

    cfg = Config(
        qdrant_host=args.qdrant_host,
        qdrant_port=args.qdrant_port,
        qdrant_api_key=args.qdrant_api_key,
        qdrant_collection=args.qdrant_collection,
        vector_top_k=args.top_k,
        neo4j_uri=args.neo4j_uri,
        neo4j_user=args.neo4j_user,
        neo4j_password=args.neo4j_password,
        graph_top_k=args.top_k,
        serper_api_key=args.serper_api_key,
        serper_top_k=args.top_k,
        openai_api_key=args.openai_api_key,
        embedding_model_name="text-embedding-3-small",
    )

    agent = MRetrievalAgent(cfg)
    pred_idx, messages = agent.predict(problems, args.shot_qids, args.qid)
    print(f"Predicted answer index: {pred_idx}")
    print("\n--- Retrieval Messages ---")
    if isinstance(messages, list):
        for m in messages:
            print(m)
            print("\n---\n")
    else:
        print(messages)


if __name__ == "__main__":
    main()