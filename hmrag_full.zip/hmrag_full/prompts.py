"""
Prompt utilities for ScienceQA/HM‑RAG.

This module defines a set of helper functions for constructing
prompts used in few‑shot learning for ScienceQA.  The functions
convert the structured problem dictionary into concatenated strings
containing the question, context, answer choices and optional
explanations (lecture/solution).  The implementation is copied
verbatim from the user‑provided code, with the addition of a
module‑level docstring and minor clarifications in comments.
"""

from typing import Dict, List


def get_question_text(problem: Dict) -> str:
    return problem["question"]


def get_context_text(problem: Dict, use_caption: bool) -> str:
    txt_context = problem.get("hint", "")
    img_context = problem.get("caption", "") if use_caption else ""
    context = " ".join([txt_context, img_context]).strip()
    if context == "":
        context = "N/A"
    return context


def get_choice_text(problem: Dict, options: List[str]) -> str:
    choices = problem["choices"]
    choice_list = []
    for i, c in enumerate(choices):
        choice_list.append("({}) {}".format(options[i], c))
    choice_txt = " ".join(choice_list)
    return choice_txt


def get_answer(problem: Dict, options: List[str]) -> str:
    return options[problem["answer"]]


def get_lecture_text(problem: Dict) -> str:
    lecture = problem["lecture"].replace("\n", "\\n")
    return lecture


def get_solution_text(problem: Dict) -> str:
    solution = problem["solution"].replace("\n", "\\n")
    return solution


def create_one_example(
    format: str,
    question: str,
    context: str,
    choice: str,
    answer: str,
    lecture: str,
    solution: str,
    test_example: bool = True,
) -> str:
    """Create a formatted example for few‑shot prompting."""
    input_format, output_format = format.split("-")
    # Inputs
    if input_format == "CQM":
        input_str = f"Context: {context}\nQuestion: {question}\nOptions: {choice}\n"
    elif input_format == "QCM":
        input_str = f"Question: {question}\nContext: {context}\nOptions: {choice}\n"
    elif input_format == "QCML":
        input_str = f"Question: {question}\nContext: {context}\nOptions: {choice}\nBECAUSE: {lecture}\n"
    elif input_format == "QCME":
        input_str = f"Question: {question}\nContext: {context}\nOptions: {choice}\nBECAUSE: {solution}\n"
    elif input_format == "QCMLE":
        input_str = f"Question: {question}\nContext: {context}\nOptions: {choice}\nBECAUSE: {lecture} {solution}\n"
    elif input_format == "QCLM":
        input_str = f"Question: {question}\nContext: {context}\nBECAUSE: {lecture}\nOptions: {choice}\n"
    elif input_format == "QCEM":
        input_str = f"Question: {question}\nContext: {context}\nBECAUSE: {solution}\nOptions: {choice}\n"
    elif input_format == "QCLEM":
        input_str = f"Question: {question}\nContext: {context}\nBECAUSE: {lecture} {solution}\nOptions: {choice}\n"
    else:
        input_str = f"Question: {question}\nContext: {context}\nOptions: {choice}\n"
    # Outputs
    if test_example:
        output_str = "Answer:"
    elif output_format == "A":
        output_str = f"Answer: The answer is {answer}."
    elif output_format == "AL":
        output_str = f"Answer: The answer is {answer}. BECAUSE: {solution}"
    elif output_format == "AE":
        output_str = f"Answer: The answer is {answer}. BECAUSE: {lecture}"
    elif output_format == "ALE":
        output_str = f"Answer: The answer is {answer}. BECAUSE: {lecture} {solution}"
    elif output_format == "AEL":
        output_str = f"Answer: The answer is {answer}. BECAUSE: {solution} {lecture}"
    elif output_format == "LA":
        output_str = f"Answer: {lecture} The answer is {answer}."
    elif output_format == "EA":
        output_str = f"Answer: {solution} The answer is {answer}."
    elif output_format == "LEA":
        output_str = f"Answer: {lecture} {solution} The answer is {answer}."
    elif output_format == "ELA":
        output_str = f"Answer: {solution} {lecture} The answer is {answer}."
    else:
        output_str = "Answer:"
    text = input_str + output_str
    text = text.replace("  ", " ").strip()
    if text.endswith("BECAUSE:"):
        text = text.replace("BECAUSE:", "").strip()
    return text


def build_prompt(problems: Dict[str, Dict], shot_qids: List[str], test_qid: str, args) -> str:
    """Construct the prompt for few‑shot prompting."""
    examples = []
    # Build examples for the few‑shot questions
    for qid in shot_qids:
        question = get_question_text(problems[qid])
        context = get_context_text(problems[qid], args.use_caption)
        choice = get_choice_text(problems[qid], args.options)
        answer = get_answer(problems[qid], args.options)
        lecture = get_lecture_text(problems[qid])
        solution = get_solution_text(problems[qid])
        train_example = create_one_example(
            args.prompt_format,
            question,
            context,
            choice,
            answer,
            lecture,
            solution,
            test_example=False,
        )
        examples.append(train_example)
    # Build the example for the current question (without answer)
    question = get_question_text(problems[test_qid])
    context = get_context_text(problems[test_qid], args.use_caption)
    choice = get_choice_text(problems[test_qid], args.options)
    answer = get_answer(problems[test_qid], args.options)
    lecture = get_lecture_text(problems[test_qid])
    solution = get_solution_text(problems[test_qid])
    test_example = create_one_example(
        args.prompt_format,
        question,
        context,
        choice,
        answer,
        lecture,
        solution,
        test_example=True,
    )
    examples.append(test_example)
    # Join examples with blank lines
    prompt_input = "\n\n".join(examples)
    return prompt_input