from typing import Any, List, Tuple

from .decompose_agent_hosted import DecomposeAgentHosted
from .retrieval.vector_retrieval import VectorRetrieval
from .retrieval.graph_retrieval import GraphRetrieval
from .retrieval.web_retrieval import WebRetrieval
from .summary_agent_hosted import SummaryAgentHosted


class MRetrievalAgentHosted:
    def __init__(self, config: Any):
        self.config = config
        self.vector_retrieval = VectorRetrieval(config)
        self.graph_retrieval = GraphRetrieval(config)
        self.web_retrieval = WebRetrieval(config)
        self.sum_agent = SummaryAgentHosted(config)
        self.dec_agent = DecomposeAgentHosted(config)

    def predict(self, problems, shot_qids, qid):
        problem = problems[qid]
        question = problem["question"]
        choices = problem.get("choices", [])
        answer_idx = problem.get("answer", "?")
        hint = problem.get("hint", "")
        image = problem.get("image", "")

        print("\n" + "#"*80)
        print("#  HM-RAG MULTI-RETRIEVAL PIPELINE")
        print("#"*80)
        print(f"  QID:      {qid}")
        print(f"  Split:    {problem.get('split', '?')}")
        print(f"  Question: {question}")
        print(f"  Choices:  {choices}")
        print(f"  Hint:     {hint or '(none)'}")
        print(f"  Image:    {image or '(none)'}")
        print(f"  GT Answer Index: {answer_idx}")
        if isinstance(answer_idx, int) and answer_idx < len(choices):
            print(f"  GT Answer Text:  {choices[answer_idx]}")

        # ── STEP 1: DECOMPOSE ──
        print("\n" + "▓"*60)
        print("▓  STEP 1: QUESTION DECOMPOSITION")
        print("▓"*60)
        question = self.dec_agent.decompose(question)
        if isinstance(question, str):
            print(f"\n  📋 Decomposition result (single query): {question}")
        else:
            print(f"\n  📋 Decomposition result ({len(question)} sub-queries):")
            for i, sq in enumerate(question, 1):
                print(f"     [{i}] {sq}")

        # ── STEP 2a: VECTOR RETRIEVAL ──
        print("\n" + "▓"*60)
        print("▓  STEP 2a: VECTOR RETRIEVAL (Qdrant)")
        print("▓"*60)
        print(f"  🔍 Query to embed: {question}")
        vector_response = self.vector_retrieval.find_top_k(question)
        print(f"\n  📦 Vector retrieval response:")
        for line in vector_response.split("\n"):
            print(f"     {line}")

        # ── STEP 2b: GRAPH RETRIEVAL ──
        print("\n" + "▓"*60)
        print("▓  STEP 2b: GRAPH RETRIEVAL (Neo4j)")
        print("▓"*60)
        print(f"  🕸️  Query for graph: {question}")
        graph_response = self.graph_retrieval.find_top_k(question)
        print(f"\n  📦 Graph retrieval response:")
        for line in graph_response.split("\n"):
            print(f"     {line}")

        # ── STEP 2c: WEB RETRIEVAL ──
        print("\n" + "▓"*60)
        print("▓  STEP 2c: WEB RETRIEVAL (Serper)")
        print("▓"*60)
        print(f"  🌐 Query for web: {question}")
        web_response = self.web_retrieval.find_top_k(question)
        print(f"\n  📦 Web retrieval response:")
        for line in web_response.split("\n"):
            print(f"     {line}")

        # ── EVIDENCE FUSION ──
        all_messages = [
            "Vector Retrieval Agent:\n" + vector_response + "\n",
            "Graph Retrieval Agent:\n" + graph_response + "\n",
            "Web Retrieval Agent:\n" + web_response + "\n",
        ]

        print("\n" + "▓"*60)
        print("▓  STEP 3: EVIDENCE FUSION & ANSWER SYNTHESIS")
        print("▓"*60)
        print(f"  📚 Total evidence sources: 3")
        print(f"     Vector: {len(vector_response.split(chr(10)))} lines")
        print(f"     Graph:  {len(graph_response.split(chr(10)))} lines")
        print(f"     Web:    {len(web_response.split(chr(10)))} lines")

        final_ans, final_messages = self.sum_agent.summarize(problems, shot_qids, qid, all_messages)

        print("\n" + "▓"*60)
        print("▓  FINAL RESULT")
        print("▓"*60)
        print(f"  🎯 Predicted answer index: {final_ans}")
        if isinstance(final_ans, int) and final_ans < len(choices):
            print(f"  🎯 Predicted answer text:  {choices[final_ans]}")
        print(f"  ✅ Ground truth index:     {answer_idx}")
        if isinstance(answer_idx, int) and answer_idx < len(choices):
            print(f"  ✅ Ground truth text:      {choices[answer_idx]}")
        is_correct = (final_ans == answer_idx)
        if is_correct:
            print(f"  🟢 CORRECT!")
        else:
            print(f"  🔴 INCORRECT!")
        print("#"*80 + "\n")

        return final_ans, final_messages
