"""
Multi‑retrieval agent for HM‑RAG.

This module glues together the three retrieval modalities (vector, graph
and web) with the decomposition and summarisation agents.  It
implements the simple orchestrator described in the HM‑RAG paper: it
accepts a single question (and optional few‑shot examples) and
produces a final answer by consulting each retrieval source and then
passing the combined evidence to a summary agent.  The code here is
intentionally unchanged from the original implementation provided by
the user; only formatting and docstring have been added for clarity.

The ``predict`` method runs the following steps:

1. Decompose the input question into sub‑queries if necessary.
2. Retrieve top‑k results from the vector store, knowledge graph and
   web search.
3. Combine the results into a list of messages and feed them to the
   summary agent to generate the final answer index and messages.

See the HM‑RAG documentation for details.
"""

from typing import List

from retrieval.vector_retrieval import VectorRetrieval
from retrieval.graph_retrieval import GraphRetrieval
from retrieval.web_retrieval import WebRetrieval
from summary_agent import SummaryAgent
from decompose_agent import DecomposeAgent


class MRetrievalAgent:
    """Multi‑source retrieval agent.

    This class instantiates and manages the vector, graph and web
    retrieval components as well as the decomposition and summary
    agents.  It exposes a ``predict`` method that accepts the problem
    dictionary, optional few‑shot identifiers and a question ID, and
    returns the predicted answer index along with intermediate
    messages.
    """

    def __init__(self, config) -> None:
        self.config = config
        self.vector_retrieval = VectorRetrieval(config)
        self.graph_retrieval = GraphRetrieval(config)
        self.web_retrieval = WebRetrieval(config)
        self.sum_agent = SummaryAgent(config)
        self.dec_agent = DecomposeAgent(config)

    def predict(self, problems: dict, shot_qids: List[str], qid: str):
        """Run the full retrieval and summarisation pipeline.

        Parameters
        ----------
        problems : dict
            The full dataset of problems keyed by question ID.
        shot_qids : list of str
            Optional list of question IDs to use for few‑shot prompting.
        qid : str
            The ID of the question to process.

        Returns
        -------
        tuple
            ``(predicted_index, messages)`` where ``predicted_index``
            is the zero‑based index of the predicted answer choice and
            ``messages`` is a list of strings containing the retrieval
            agent outputs.
        """
        problem = problems[qid]
        question = problem["question"]
        # Decompose the question into sub‑queries if necessary
        question = self.dec_agent.decompose(question)

        # Retrieve from each modality
        vector_response = self.vector_retrieval.find_top_k(question)
        graph_response = self.graph_retrieval.find_top_k(question)
        web_response = self.web_retrieval.find_top_k(question)

        # Assemble messages for the summarisation agent.  Note: the
        # original implementation duplicated the graph response twice;
        # we preserve that behaviour for fidelity.
        all_messages = [
            "Vector Retrieval Agent:\n" + vector_response + "\n",
            "Graph Retrieval Agent:\n" + graph_response + "\n"
            "Graph Retrieval Agent:\n" + graph_response + "\n",
        ]

        final_ans, final_messages = self.sum(problems, shot_qids, qid, all_messages)
        return final_ans, final_messages

    def sum(self, problems: dict, shot_qids: List[str], qid: str, sum_question: List[str]):
        """Delegate to the summary agent to produce the final answer.

        Parameters
        ----------
        problems : dict
            The full dataset of problems.
        shot_qids : list of str
            Few‑shot example question IDs.
        qid : str
            The current question ID.
        sum_question : list of str
            A list of retrieval messages to be summarised.

        Returns
        -------
        tuple
            ``(predicted_index, messages)`` as returned by the summary agent.
        """
        final_ans, all_messages = self.sum_agent.summarize(problems, shot_qids, qid, sum_question)
        return final_ans, all_messages